﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea1_Panaderia_
{
    public enum Tipo{ Conchas, Cuernitos, Orejas, Donas}
    public class Pan
    {
        public byte Cantidad {  get; set; }
     
        
        
        private decimal TotalPagando
        {
            get
            {
                return Cantidad * Precio;
            }
        }

        private decimal total
        {
     
            get
            {
                decimal dinero = 0;
                return dinero += TotalPagando;
            }
        }

        public decimal Total
        {
            get { return total; }
        }
        public decimal Precio
        {
            get
            {
               if(Tipo == Tipo.Conchas)
                {
                    return 15;
                }
               if (Tipo == Tipo.Cuernitos)
                {
                    return 10;
                }
               if(Tipo ==Tipo.Orejas)
                {
                    return 12;
                }
               if(Tipo == Tipo.Donas)
                {
                    return 17;
                }
                return 0;
            }
        }
        public Tipo Tipo { get; set; }


    }
}
