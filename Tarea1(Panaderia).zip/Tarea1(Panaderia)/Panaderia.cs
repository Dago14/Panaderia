﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;

namespace Tarea1_Panaderia_
{
    public class Panaderia: INotifyPropertyChanged
    {
        public ObservableCollection<Pan> Panes { get; set; } = new();
        
        public ICommand AgregarCommand { get; set; }
        public ICommand EliminarCommand { get; set; }
        public Pan Pan { get; set; } = new();

       
     
        public Panaderia()
        {
         
            AgregarCommand = new RelayCommand<Pan>(Agregar);
            EliminarCommand = new RelayCommand(Eliminar);
        }
        public void Agregar(Pan? cantidad)
        {


            if (cantidad != null)
            {

                Panes.Add(cantidad);
              
                Pan = new();
                PropertyChanged?.Invoke(this, new(nameof(Pan)));

               
            }
           
        }

        public void Eliminar()
        {
            if(Pan !=  null)
            {
                Panes.Remove(Pan);
            }

        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
